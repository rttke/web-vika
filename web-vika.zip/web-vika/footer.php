<div class="container footer">
    <div class="end">
        <a href="https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox?compose=CllgCKCBBNJbqKmWftKVSPBWjCFGbVLwhJsSjsGzJQznJTsQgRqjmmfdTCrjjKwZhSnVtxWrMHg"
           class="tx1">info@gmail.com</a>
        <a href="https://vk.com/vika_bukreeva" class="tx2">Информация о разработчике</a>
    </div>
</div>
</body>
</html>