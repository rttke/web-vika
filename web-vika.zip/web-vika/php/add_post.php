<form action="action_db.php" method="post">
  <input type="text" placeholder="Название" name="title">
  <button type="submit">Выложить</button>
</form>